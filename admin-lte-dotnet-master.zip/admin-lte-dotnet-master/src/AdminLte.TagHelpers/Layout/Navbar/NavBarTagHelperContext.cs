﻿namespace AdminLte.TagHelpers.Layout.Navbar
{
    public class NavBarTagHelperContext
    {
        public string NavbarLeftHtml { get; set; }

        public string NavbarRightHtml { get; set; }
    }
}
