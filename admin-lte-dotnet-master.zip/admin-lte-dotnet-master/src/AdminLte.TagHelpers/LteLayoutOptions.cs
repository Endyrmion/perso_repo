﻿using System.Collections.Generic;

namespace AdminLte.TagHelpers
{
    public class LteLayoutOptions
    {
        public List<string> WrapperClasses { get; } = new List<string>();
    }
}
