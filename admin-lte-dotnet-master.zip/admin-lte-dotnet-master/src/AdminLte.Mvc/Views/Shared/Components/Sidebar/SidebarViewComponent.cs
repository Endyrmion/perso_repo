﻿using Microsoft.AspNetCore.Mvc;

namespace AdminLte.Mvc.Views.Shared.Components.Sidebar
{
    public class SidebarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke() => View();
    }
}