﻿using Microsoft.AspNetCore.Mvc;

namespace AdminLte.Mvc.Views.Shared.Components.HeaderSearchForm
{
    public class HeaderSearchFormViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke() => View();
    }
}