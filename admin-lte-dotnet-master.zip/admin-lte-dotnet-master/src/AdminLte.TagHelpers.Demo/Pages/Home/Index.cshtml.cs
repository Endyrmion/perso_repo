﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AdminLte.TagHelpers.Demo.Pages.Home
{
    public class IndexModel : PageModel
    {
    }
}