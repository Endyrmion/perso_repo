﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AdminLte.RazorPages.Pages.Home
{
    public class IndexModel : PageModel
    {
    }
}