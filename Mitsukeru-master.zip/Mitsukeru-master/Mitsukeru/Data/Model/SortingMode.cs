﻿namespace Mitsukeru.Data.Model
{
    public enum SortingMode
    {
        AlphabeticalAsc,
        AlphabeticalDesc,
        RelevanceDesc,
        PublicRatingsDesc
    }
}